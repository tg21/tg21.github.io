import java.servlet.jsp.target.*;
import java.servlet.jsp.*;
import java.io.*;
import java.util.*;

public class p7 extends simpleTagSupport{
    String input;
    int start,end;
    public void setInput(String input){
        this.input = input;
    }
    public void setStart(int start){
        this.Start = start;
    }
    public void setInput(int end){
        this.end = end;
    }
    public void doTag() throws JspException,IOException{
        JspWriter out = getJspContext().getOut();
        if(start>=0 && end<input.length()){
            for(int i=start;i<=end;i++){
                out.print(input.charAt(i));
            }
            
        }else {out.println("wrong inputs");}
    }
}