num = as.numeric(readline("Enter a number :- "))
sum = 0
for(i in 0:num){
  sum = sum + i
}
cat("sum is ",sum)

