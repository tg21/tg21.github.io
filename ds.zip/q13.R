s1 = sample(1:6,40,replace = TRUE)
s2 = sample(1:6,70,replace = TRUE)
s3 = sample(1:6,100,replace = TRUE)
outcomes = c(1,2,3,4,5,6)
ideal = data.frame(face = outcomes,probablity = c(rep(0.167,6)))
s1t = table(s1)
s2t = table(s2)
s3t = table(s3)
print("*Probalblity of a number appearing on a fair die is 1/6 or 0.167*")
cat("SAMPLE 1 => ",s1)
p1 = c()
for(i in 1:6){
  temp = s1t[[i]]/40
  p1 = c(p1,temp)
  cat("Probablity of occurance of ",i," in s1 is ",temp,"\n")
  
}
p1 = data.frame(face = outcomes,probablity = p1)

p2 = c()
for(i in 1:6){
  temp = s2t[[i]]/70
  p2 = c(p2,temp)
  cat("Probablity of occurance of ",i," in s2 is ",temp,"\n")
  
}
p2 = data.frame(face = outcomes,probablity = p2)

p3 = c()
for(i in 1:6){
  temp = s3t[[i]]/100
  p3 = c(p3,temp)
  cat("Probablity of occurance of ",i," in s3 is ",temp,"\n")
  
}
p3 = data.frame(face = outcomes,probablity = p3)

print("With No. of samples increasing the probalblity is getting near to 1/6")

plot(p1,bg = "red",pch=21, main = "SCATTER PLOT OF SAMPLES", xlab = "faces of die", ylab = "probablity of occurance","p")
points(p2,bg="blue",pch=21)
points(p3 ,bg="green",pch=21)
lines(ideal)
