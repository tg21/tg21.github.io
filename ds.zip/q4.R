n = as.integer(readline("enter a number from 1 to 12 :- "))
if(n>12 || n<1){
  cat("try again!")
}else{
  for(i in 1:10){
    cat(n," * ",i," = ",n*i,"\n")
  }
}