runTotal = function(lst){
  sum = 0
  for(i in 1:length(lst)){
    sum = sum + lst[i]
  }
  cat("Running Total of list is = ",sum)
}

a = c(1,2,3,4,5,6)
runTotal(a)
