mode = function(lst){
  tab = table(lst)
  return(names(tab)[tab == max(tab)])
}

ages = c(20,20,20,20,20,21,21,21,22,22,22,22,23,23,23)
cat("ages of 15 students are :- ",ages)
cat("Median of ages less than 22 is ", median(ages[ages<22]))
cat("Median of all ages is ",median(ages))
cat("Mean of ages of all students is ",mean(ages))
cat("Mode ofall ages is ",mode(ages))

print("**Two more students enter the class. The age of both students is 23**")
ages = c(ages,c(23,23))
cat("ages of 17 students are :- ",ages)
cat("Median of ages less than 22 is ", median(ages[ages<22]))
cat("Median of all ages is ",median(ages))
cat("Mean of ages of all students is ",mean(ages))
cat("Mode ofall ages is ",mode(ages))
