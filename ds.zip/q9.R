binary = function(lst,query){
  lst = sort(lst)
  first = 1
  last = length(lst)
  found = FALSE
  while(first<=last){
    mid = (first+last)%/%2
    if(query == lst[mid]){
      cat(query," found at index ",mid)
      found = TRUE
      break
    }else if(query>lst[mid]){
      first = mid+1
    }else{
      last = mid -1
    }
  }
  if(!found){
    cat("SEARCH RESULT CAME EMPTY")
  }
}

a = c(20,30,50,60)
num = 50

binary(a,50)
