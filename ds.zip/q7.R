palindrome = function(word){
  letters = strsplit(word,"")[[1]]
  if(identical(letters,rev(letters))){
    cat(word," is a palindrome")
  }else{
    print("not palindrome")
  }
}

input = readline("enter a word :- ")
#input = "abrba"
palindrome(input)
