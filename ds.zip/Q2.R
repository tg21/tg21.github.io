print("Hello World")
