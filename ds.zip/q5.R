largest = function(lst){
  l = lst[1]
  for(i in 2:length(lst) ){
    if(l<lst[i]){
      l = lst[i]
    }else{
      next
    }
   
  }
  cat("largest number is ",l)
}

a = c(2,3,1,41,21)
# n = as.integer(readline("enter size of list := "))
# for(i in 1:n){
#   a = c(a,as.integer(readline("enter element")))
# }

largest(a)
