print("MATRIX A")
an = as.integer(readline("Enter number of rows : "))
am = as.integer(readline("Enter number of cols : "))
print("Enter values : ")
f = matrix(scan(n=an*am),an,am,TRUE)
print(f)

print("MATRIX B")
bn = as.integer(readline("Enter number of rows : "))
bm = as.integer(readline("Enter number of cols : "))
print("Enter values : ")
s = matrix(scan(n=an*am),bn,bm,TRUE)
print(s)

if(an==bn && am==bm){
  print("Sum of Matrices")
  print(f+s)
  print("Difference of Matrices")
  print(f-s)
  }else{
    print("Invalid Dimensions for Sum and Difference of Matrix")
  }

if(am==bn)
{
  print("Product of Matrices")
  print(f %*% s)
}else
{
  print("Invalid Dimensions for Product of Matrix")
}
