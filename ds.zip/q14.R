library(lattice)
library(tidyverse)
s = sample(1:10,20,replace = TRUE)
t = sample(1:10,20,replace = TRUE)

d = data.frame(s,t)
d
# using base 
plot(d,type = "o",main="BASE Plot",xlab="Sample s",ylab="Sample t")

#usinf lattice
barchart(d)
xyplot(s~t)
histogram(s~t,data =d)
dotplot(s~t)
levelplot(s~t)
stripplot(s~t,data = d)

#using ggplot
ggplot(d,aes(x=s,y=t))+geom_point()+geom_smooth()
ggplot(d,aes(x=s,fill=t))+geom_histogram()
ggplot(d,aes(x=s))+geom_abline()
ggplot(d,aes(x=s,color = t))+geom_density()
