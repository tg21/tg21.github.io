linear = function(lst,queary){
  flag = FALSE
  for(i in 1:length(lst)){
    if(queary == lst[i]){
      cat(queary," found at ",i," index")
      flag = TRUE
      break
    }
  }
  if(!flag){
    print("NOTHING FOUND IN SEARCH")
  }
}

a = c(1,2,3,4,5,6)
linear(a,7)
