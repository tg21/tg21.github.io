#include<iostream>
#include <graphics.h>
using namespace std;

int main(){
	
	int gd = DETECT,gm;
	initgraph(&gd,&gm,NULL);

	int xa,ya,xb,yb;
	cout<<"Enter Values of xa,ya,xb,yb\n";
	cin>>xa>>ya>>xb>>yb;
	int dx = xb - xa;
	int dy = yb - ya;
	int dstart = 2*dy - dx;
	int dE = 2*dy;
	int dNE = 2*(dy-dx);

	int x = xa;
	int y = ya;

	putpixel(x,y,RED);

	for(int i=0;i<dx-1;i++){
		if(dstart<0){
			x += 1;
			dstart += dE;
		}else{
			x+=1;
			y+=1;
			dstart += dNE;
		}
		putpixel(x,y,RED);
	}
	cout<<"\ndone\n";
	cin>>x;
	closegraph();
	return 0;
}