// Sutherland -cohen line clipping

#include <iostream>
#include <graphics.h>
using namespace std;

class outcode{
public:
	bool t,b,r,l;
	outcode(){
		t=0;
		b=0;
		r=0;
		l=0; 
	}
	bool inRegion(){
		if(t or b or r or l){
			return false;
		}else{
			return true;
		}
	}
};
int xmin,ymin,xmax,ymax,xa,ya,xb,yb;
outcode p;
outcode q;
void tbrl(int x, int y,outcode &z){
	if(y>ymax) z.t = 1;
	if(y<ymin) z.b = 1;
	if(x>xmax) z.r = 1;
	if(x<xmin) z.l = 1;
	
}
int main()
{
	int gd = DETECT,gm;
	initgraph(&gd,&gm,NULL);

	cout<<"Enter cooridinates of line (x0,y0) and (x1,y1)\n";
	cin>>xa>>ya>>xb>>yb;
	outtextxy(10, 10, "Line befor clipping");
	cout<<"drawing line\n";
	line(xa,ya,xb,yb);
	cout<<"Enter values of x-min, y-min, x-max, y-max\n";
	cin>>xmin>>ymin>>xmax>>ymax;
	cout<<"drawing rectangle\n";
	rectangle(xmin,ymax,xmax,ymin);

	tbrl(xa,ya,p);
	cout<<"p is "<<p.t<<p.b<<p.r<<p.l;
	tbrl(xb,yb,q);
	cout<<"\n<<q is "<<q.t<<q.b<<q.r<<q.l<<endl;

	cin.get();

	if(p.inRegion() && q.inRegion()){
		cout<<"Line already in completely inside clipping region\n";


	}else{
		if((p.t and q.t) or (p.b and q.b) or (p.r and q.r) or (p.l and q.l)){
			cleardevice();
			outtextxy(10, 10, "Line was completely outside clipping region");
			rectangle(xmin,ymax,xmax,ymin);
		}
		else{
			int x3,y3,x4,y4;
			float m = (yb-ya)/(xb-xa);
			if(p.r){
				x3 = xmax;
				y3 = yb + m*(x3-xb);
			}else if(p.l){
				x3 = xmin;
				y3 = yb + m*(x3-xb);
			}else if(p.t){
				y3 = ymax;
				x3 = xb +(y3-yb)/m;
			}else if(p.b){
				y3 = ymin;
				x3 = xb +(y3-yb)/m;
			}else{
				x3 = xa;
				y3 = ya;
			}


			if(q.r){
				x4 = xmax;
				y4 = ya + m*(x4-xa);
			}else if(q.l){
				x4 = xmin;
				y4 = ya + m*(x4-xa);
			}else if(q.t){
				y4 = ymax;
				x4 = xa +(y4-ya)/m;
			}else if(q.b){
				y4 = ymin;
				x4 = xa +(y4-ya)/m;
			}else{
				x4 = xb;
				y4 = yb;
			}

			cleardevice();
			outtextxy(10, 10, "Line after clipping");
			rectangle(xmin,ymax,xmax,ymin);
			line(x3,y3,x4,y4);


		}
	}
	cin.get();
	closegraph();
	return 0;
}