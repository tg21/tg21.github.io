//Program 2: Write a program to implement mid-point circle drawing algorithm

#include <iostream>
#include <graphics.h>
using namespace std;
int h,k,r;

void plotocto(int x,int y){
	putpixel(x+h,y+k,2);
    putpixel(y+h,x+k,3);
    putpixel(y+h,-x+k,4);
    putpixel(x+h,-y+k,5);
    putpixel(-x+h,-y+k,6);
	putpixel(-y+h,-x+k,7);
    putpixel(-y+h,x+k,8);
    putpixel(-x+h,y+k,9);
}

int main()
{
	int gd = DETECT,gm;
	initgraph(&gd,&gm,NULL);
	
	cout<<"enter origin of circle and radius(x0,y0,r)\n";
	cin>>h>>k>>r;
	
	int x = 0;
	int y = r;
	int p = 1-r;

	putpixel(x+h,y+k,1);
	while(x<y){
		if(p<0){
			p = p + 2*x + 3;
			x+=1;
		}else{
			p = p + 2*(x-y)+5;
			x+=1;
			y-=1;
			
		}
		putpixel(x+h,y+k,1);
		plotocto(x,y);
	}

	cout<<"\ndone\n";
	cin>>x;
	closegraph();

	return 0;
}